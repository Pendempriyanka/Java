package com.alti.testproject.testproject;

public class FibonacciAndFactorial {

	public static void main(String[] args) {
		/** Fibonacci Series **/
		int n = 10, t1 = 0, t2 = 1;
        System.out.print("First " + n + " terms: ");
        for (int i = 1; i <= n; ++i){
            System.out.print(t1 + " ");
            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }
        
        System.out.println();
        
        /** Factorial Number **/
        int num = 5;
        long factorial = 1;
        for(int i = 1; i <= num; ++i) {
            factorial *= i;
        }
        System.out.printf("Factorial of %d = %d", num, factorial);

	}

}
