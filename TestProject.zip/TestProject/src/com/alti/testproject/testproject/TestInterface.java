package com.alti.testproject.testproject;

public interface TestInterface {
	
	void m1();
	/*void m2();
	void m3();
	void m4();
	void m5();
	void m6();
	void m7();
	void m8();
	void m0();*/
}
