package com.alti.testproject.testproject;

public class SelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
