package com.alti.testproject.testproject;

public class MergeTwoArraySortingOrder {

	public static void main(String[] args) {
		
		int[] intA = {1, 2, 3, 4, 5};
		int[] intB = {10, 9, 8, 7, 6};
		int[] intC = new int[intA.length+intB.length];
		int count = 0;
		for(int i = 0; i < intA.length; i++) { 
			intC[i] = intA[i];
			count++;
		} 
		for(int j = 0; j < intB.length;j++) { 
			intC[count++] = intB[j];
		}
		
		/** Ascending Order > and Descending order **/
		int temp;
		for (int i = 0; i < intC.length; i++) {
            for (int j = i + 1; j < intC.length; j++) {
                if (intC[i] > intC[j]) {
                    temp = intC[i];
                    intC[i] = intC[j];
                    intC[j] = temp;
                }
            }
        }
		
		for(int i = 0;i < intC.length;i++) System.out.print(intC[i]+" ");
	}
}
