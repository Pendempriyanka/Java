package com.alti.testproject.testproject;

import java.util.HashMap;

public class CountOfDuplicatesWords {

	public static void main(String[] args) {
		
		/** Java 1.7 **/
		String input="Welcome to Java Session Session Session";
		String[] words=input.split(" ");
		int wrc=1;
		for(int i=0;i<words.length;i++)	{
			for(int j=i+1;j<words.length;j++){	
			if(words[i].equals(words[j])){
					wrc=wrc+1;
					words[j]="0";
				}
			}
			if(words[i]!="0")
			System.out.println(words[i]+"--"+wrc);
			wrc=1;
	     }
		
		/** Using HashMap **/
		String str = "Welcome to Java Session Session Session";
		String[] split = str.split(" ");
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		for (int i=0; i<split.length; i++) {
		    if (map.containsKey(split[i])) {
		        int count = map.get(split[i]);
		        map.put(split[i], count+1);
		    } else {
		        map.put(split[i], 1);
		    }
		}
		System.out.println(map);
	}

}
