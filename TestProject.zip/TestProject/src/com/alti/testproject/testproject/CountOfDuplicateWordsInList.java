package com.alti.testproject.testproject;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CountOfDuplicateWordsInList {

	public static void main(String[] args) {
		 List<String> list = Arrays.asList("aaa", "bbb" , "aaa");
	     // we can also use Function.identity() instead of c->c
	    Map<String ,Long> map = list.stream()
	            .collect(Collectors.groupingBy(c -> c , Collectors.counting())) ;
	    map.forEach(   (k , v ) -> System.out.println( k + " : "+ v ));
	}

}
