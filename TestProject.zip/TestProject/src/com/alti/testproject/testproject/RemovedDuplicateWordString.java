package com.alti.testproject.testproject;

import java.util.Arrays;
import java.util.stream.Collectors;

public class RemovedDuplicateWordString {

	public static void main(String[] args) {
		/** Java 1.8 **/
		String str =   "The first second was alright but the second second was tough.";    
	    str = Arrays.stream(str.split("\\s")).distinct().collect(Collectors.joining(" "));    
	    System.out.println(str);
	    
	}
}
