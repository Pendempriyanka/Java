package com.alti.testproject.testproject;

import java.util.Scanner;

public class SwapTwoNumberWithoutThirdVariable {

	public static void main(String args[]){
	      int x, y;
	      System.out.println("Enter x and y");
	      Scanner in = new Scanner(System.in);
	      x = in.nextInt();
	      y = in.nextInt();
	      System.out.println("Before Swapping\nx = "+x+"\ny = "+y);
	      x = x + y; // 2 + 1 = 3
	      y = x - y; // 3 - 1 = 2
	      x = x - y; // 3 - 2 = 1
	      System.out.println("After Swapping without third variable\nx = "+x+"\ny = "+y);
	}
}
