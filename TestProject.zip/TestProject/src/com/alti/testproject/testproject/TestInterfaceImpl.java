package com.alti.testproject.testproject;

class TestInterfaceImpl implements TestInterface{

	public void m1() {
		System.out.println("Hi");	
	}

	public static void main(String[] args) {
		TestInterfaceImpl test = new TestInterfaceImpl();
		test.m1();
	}
	
	
}
