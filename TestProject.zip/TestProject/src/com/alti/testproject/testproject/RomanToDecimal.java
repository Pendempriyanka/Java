package com.alti.testproject.testproject;

public class RomanToDecimal {

	public static void romanToDecimal(String romanNumber) {
        int decimal = 0;
        int number = 0;
        String romanNumeral = romanNumber.toUpperCase();
        for (int x = romanNumeral.length() - 1; x >= 0 ; x--) { // XIV
            char convertToDecimal = romanNumeral.charAt(x);

            switch (convertToDecimal) {
                case 'M':
                    decimal = processDecimal(1000, number, decimal);
                    number = 1000;
                    break;

                case 'D':
                    decimal = processDecimal(500, number, decimal);
                    number = 500;
                    break;

                case 'C':
                    decimal = processDecimal(100, number, decimal);
                    number = 100;
                    break;

                case 'L':
                    decimal = processDecimal(50, number, decimal);
                    number = 50;
                    break;

                case 'X':
                    decimal = processDecimal(10, number, decimal);
                    number = 10;
                    break;

                case 'V':
                    decimal = processDecimal(5, number, decimal);
                    number = 5;
                    break;

                case 'I':
                    decimal = processDecimal(1, number, decimal);
                    number = 1;
                    break;
            }
        }
        System.out.println(decimal);
    }

    public static int processDecimal(int decimal, int number, int lastDecimal) {
        if (number > decimal) {
            return lastDecimal - decimal;
        } else {
            return lastDecimal + decimal;
        }
    }

    public static void main(String args[]) {
        romanToDecimal("XIV");
    }

}
