package com.alti.testproject.testproject;

public class ArmStrongNumber {

	public static void main(String[] args) {
		
		/** ArmStrong Number (1*1*1=1) + (5*5*5 = 125) + (3*3*3 = 27) -> (153)**/
		int a = 181, number, sum = 0;
		while(a > 0) {
			number = a % 10; 
			a = a / 10;
			sum = sum + (number * number * number);
		}
		System.out.println(sum);
	}

}
