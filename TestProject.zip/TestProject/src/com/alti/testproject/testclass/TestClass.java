package com.alti.testproject.testclass;

public class TestClass {
	
	public static void main(String[] args) {
		String string = new String("Test");
		String b = string;
		System.out.println(string == b);
	}
}